# Table 1 - All models metrics per scenario

| Scenario | Model | MCC [95% CI] | QWK [95% CI] | Bal. acc. | F1 macro | Adj. acc. | n test | Perm. p |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| S1: Gene-level | ExtraTrees | 0.278 [0.236, 0.318] | 0.469 [0.420, 0.513] | 0.415 | 0.424 | 0.915 | 1,325 | 0.0099 |
| S1b: Gene-level + disease context | ExtraTrees | 0.577 [0.539, 0.616] | 0.803 [0.780, 0.825] | 0.710 | 0.710 | 0.993 | 1,325 | 0.0099 |
| S2: Combined | OrdinalDecomp | 0.681 [0.649, 0.714] | 0.839 [0.818, 0.860] | 0.722 | 0.745 | 0.991 | 1,325 | 0.0099 |
| S3: Phenotype-only | OrdinalDecomp | 0.721 [0.690, 0.752] | 0.864 [0.845, 0.882] | 0.760 | 0.767 | 0.992 | 1,325 | 0.0099 |
