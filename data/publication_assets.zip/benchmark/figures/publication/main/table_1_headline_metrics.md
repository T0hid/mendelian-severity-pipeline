# Table 1 - All models metrics per scenario

| Scenario | Model | MCC [95% CI] | QWK [95% CI] | Bal. acc. | F1 macro | Adj. acc. | n test | Perm. p |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| S1: Gene-level | ExtraTrees | 0.274 [0.236, 0.315] | 0.444 [0.397, 0.487] | 0.408 | 0.415 | 0.906 | 1,325 | n/a |
| S1b: Gene-level + disease context | ExtraTrees | 0.589 [0.550, 0.628] | 0.805 [0.780, 0.826] | 0.715 | 0.712 | 0.991 | 1,325 | n/a |
| S2: Combined | OrdinalDecomp | 0.696 [0.664, 0.729] | 0.851 [0.832, 0.870] | 0.730 | 0.754 | 0.993 | 1,325 | n/a |
| S3: Phenotype-only | OrdinalDecomp | 0.721 [0.690, 0.752] | 0.864 [0.845, 0.882] | 0.760 | 0.767 | 0.992 | 1,325 | n/a |
